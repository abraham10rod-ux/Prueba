/* Guía: calculadora, colas con prioridad y quiz */
(() => {
  const { $, $$, nf, onRoute } = FG;
  function calc() { const [w, h] = $('#gRes').value.split('x').map(Number), f = +$('#gFps').value, b = +$('#gCod').value, px = w * h * f, br = px * b;
    $('#gPx').textContent = nf(px / 1e6, 1) + ' MPx/s'; $('#gBr').textContent = nf(br / 1e6, 2) + ' Mbps'; $('#gPk').textContent = String(Math.round(br / 8 / 1400)); $('#gRaw').textContent = nf(px * 24 / 1e6, 0) + ' Mbps'; }
  ['#gRes', '#gFps', '#gCod'].forEach(i => $(i).addEventListener('change', calc)); calc();
  $('.c264').innerHTML = '<i>16×16</i>'.repeat(8);
  const codv = () => { const v = $('#gCod').value; $('#cod264').className = 'cod ' + (v === '0.07' ? 'on' : 'off'); $('#cod265').className = 'cod ' + (v === '0.045' ? 'on' : 'off'); };
  $('#gCod').addEventListener('change', codv); codv();

  /* colas */
  const CL = [['AF41 · video', '#ff9a3d', .45], ['AF31 · IoT', '#facc15', .25], ['BE · oficina', '#8ea0bd', .5]], LIM = 14;
  let Q = [[], [], []], ALL = [], drops = [0, 0, 0], sent = [0, 0, 0], cong = false, cap = 0, rr = 0, credit = [0, 0, 0], vis = false;
  function rows() { const f = $('#qSch').value === 'fifo';
    $('#qRows').innerHTML = (f ? [['Cola única FIFO', null]] : CL.map(c => [c[0], c[1]])).map((c, i) => `<div class="qrow2"><span>${c[0]}</span><div class="qslots" id="qs${i}"></div><b class="mono" id="qd${i}"></b></div>`).join(''); }
  function tick() { if (!vis) return; const f = $('#qSch').value;
    CL.forEach((c, i) => { let a = c[2] * (cong && i === 2 ? 4.5 : 1); while (a > 0) { if (Math.random() < Math.min(1, a)) { if (f === 'fifo') { ALL.length < LIM * 2 ? ALL.push(i) : drops[i]++; } else { Q[i].length < LIM ? Q[i].push(i) : drops[i]++; } } a -= 1; } });
    cap += 1.25;
    while (cap >= 1) { cap -= 1; let k = -1;
      if (f === 'fifo') { if (ALL.length) k = ALL.shift(); }
      else if (f === 'sp') { for (let i = 0; i < 3; i++) if (Q[i].length) { k = Q[i].shift(); break; } }
      else { const W = [5, 3, 2]; for (let n = 0; n < 6 && k < 0; n++) { if (Q[rr].length && credit[rr] < W[rr]) { k = Q[rr].shift(); credit[rr]++; } else { credit[rr] = 0; rr = (rr + 1) % 3; } } }
      if (k >= 0) sent[k]++; }
    if (f === 'fifo') { $('#qs0').innerHTML = ALL.map(i => `<i style="background:${CL[i][1]}"></i>`).join(''); $('#qd0').textContent = drops.reduce((a, b) => a + b, 0) + ' desc.'; }
    else Q.forEach((q, i) => { $('#qs' + i).innerHTML = q.map(() => `<i style="background:${CL[i][1]}"></i>`).join(''); $('#qd' + i).textContent = drops[i] + ' desc.'; });
    const tot = sent.reduce((a, b) => a + b, 0) || 1;
    $('#qMsg').textContent = `Descartes: video ${drops[0]} · IoT ${drops[1]} · oficina ${drops[2]}. Del enlace usado, el video ocupó ${Math.round(sent[0] / tot * 100)} %.` + (f === 'fifo' && cong ? ' Sin QoS el video se descarta igual que el resto.' : f === 'sp' && cong ? ' Con prioridad estricta el video nunca espera; la oficina se descarta.' : '');
  }
  const reset = () => { Q = [[], [], []]; ALL = []; drops = [0, 0, 0]; sent = [0, 0, 0]; rows(); };
  $('#qSch').onchange = reset; $('#qCong').onclick = () => { cong = !cong; $('#qCong').textContent = cong ? 'Quitar congestión' : 'Congestionar'; drops = [0, 0, 0]; sent = [0, 0, 0]; };
  rows(); setInterval(tick, 140);
  onRoute((p, s) => { vis = p === 'simulacion' && s === 'guia'; });

  /* quiz */
  const QZ = [
    ['Si sube la resolución de 720p a 1080p con el mismo códec y FPS, ¿qué pasa con el bitrate?', ['Se mantiene igual', 'Sube unas 2,25 veces', 'Baja a la mitad'], 1, '1080p tiene 2,25 veces más píxeles que 720p, y el bitrate es proporcional a los píxeles.'],
    ['El servidor está en la VLAN 10 y el cliente en la VLAN 20. ¿Qué equipo permite que se comuniquen?', ['El switch', 'El router', 'El cable troncal'], 1, 'El switch separa las VLAN; el router enruta entre ellas con sus subinterfaces.'],
    ['¿Qué hace la etiqueta 802.1Q en la troncal?', ['Cifra la trama', 'Indica a qué VLAN pertenece la trama', 'Cambia la IP de destino'], 1, 'La etiqueta de 4 B lleva el VID (12 bits) y la prioridad CoS (3 bits).'],
    ['Con la red llena, ¿qué logra marcar el video con DSCP AF41 y configurar CBWFQ?', ['Que el video tenga ancho de banda reservado y se descarte menos', 'Que el enlace sea más rápido', 'Que no haya ningún descarte en la red'], 0, 'QoS no crea capacidad: reparte la existente y protege la clase VIDEO.'],
    ['¿Qué cambia el router en el paquete IP al reenviarlo?', ['La IP de destino', 'El TTL y el checksum', 'El puerto UDP'], 1, 'El TTL baja en 1 y el checksum de cabecera se recalcula; las MAC y la etiqueta de VLAN también cambian, pero esas son de capa 2.'],
    ['¿Para qué sirve NMS en YOLO?', ['Para acelerar la cámara', 'Para quitar las cajas repetidas sobre un mismo objeto', 'Para comprimir el video'], 1, 'Conserva la caja de mayor confianza y elimina las que se solapan con IoU mayor al umbral.'],
    ['¿Qué tipo de red une la planta de Bogotá con una sede de monitoreo en otra ciudad a través de un ISP?', ['PAN', 'WAN', 'LAN'], 1, 'Una WAN cubre grandes distancias usando enlaces de operadores.'],
    ['¿Por qué H.265 ayuda en un enlace saturado de 20 Mbps?', ['Sube los FPS de la cámara', 'Necesita entre 40 y 50 % menos ancho de banda para la misma calidad', 'Detecta cascos sin entrenamiento'], 1, 'Sus bloques adaptativos de hasta 64×64 comprimen mejor; a cambio exige más CPU para codificar y decodificar.'],
    ['¿Por qué yolov8n.pt detecta personas de inmediato pero necesita transfer learning para detectar cascos?', ['Porque los cascos no se ven en cámara', 'Porque solo funciona en blanco y negro', 'Porque se entrenó con las 80 clases de COCO, que incluyen persona pero no EPP'], 2, 'Hay que reentrenarlo con imágenes etiquetadas de cascos y chalecos.'],
  ];
  let ok = 0, answered = 0;
  $('#quiz').innerHTML = QZ.map((q, i) => `<div class="qq" data-q="${i}"><p class="q">${i + 1}. ${q[0]}</p>${q[1].map((o, j) => `<button type="button" data-o="${j}">${String.fromCharCode(65 + j)}) ${o}</button>`).join('')}<p class="fb"></p></div>`).join('');
  $('#quiz').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; const box = b.closest('.qq'); if (box.dataset.done) return; box.dataset.done = 1; const q = QZ[+box.dataset.q], good = +b.dataset.o === q[2];
    b.classList.add(good ? 'ok' : 'ko'); if (!good) box.querySelectorAll('button')[q[2]].classList.add('ok'); box.querySelector('.fb').textContent = (good ? 'Correcto. ' : 'No exactamente. ') + q[3]; answered++; if (good) ok++;
    $('#quizScore').textContent = `Puntaje: ${ok} de ${answered}` + (answered === QZ.length ? (ok === QZ.length ? ' · ¡Excelente!' : ' · Revise la pestaña Teoría y vuelva a intentarlo.') : ''); });
})();

/* Guía: tipos de red, equipos, LAN/WAN, tráfico, YOLO, latencia */
(() => {
  const { $, $$, nf, prep, css, rr, onRoute, RM } = FG;
  $('#gNav').addEventListener('click', e => { const b = e.target.closest('button'); if (b) document.getElementById(b.dataset.go).scrollIntoView({ behavior: RM ? 'auto' : 'smooth' }); });
  const SVG = {
    PAN: `<svg viewBox="0 0 240 150"><circle cx="120" cy="75" r="58" fill="var(--brandbg)" stroke="var(--brand)" stroke-width="2" stroke-dasharray="5,5"/><circle cx="120" cy="75" r="20" fill="var(--brand)"/><text x="120" y="79" fill="#fff" font-size="9" font-weight="700" text-anchor="middle">Celular</text><rect x="40" y="28" width="52" height="22" rx="6" fill="var(--panel)" stroke="var(--brand)"/><text x="66" y="43" fill="var(--ink)" font-size="9" text-anchor="middle">Sensor IoT</text><rect x="150" y="100" width="56" height="22" rx="6" fill="var(--panel)" stroke="var(--brand)"/><text x="178" y="115" fill="var(--ink)" font-size="9" text-anchor="middle">Auriculares</text><line x1="88" y1="50" x2="106" y2="62" stroke="var(--brand)" stroke-width="2"/><line x1="152" y1="102" x2="135" y2="88" stroke="var(--brand)" stroke-width="2"/></svg>`,
    LAN: `<svg viewBox="0 0 240 150"><rect x="14" y="12" width="212" height="126" rx="14" fill="var(--brandbg)" stroke="var(--brand)" stroke-width="2"/><text x="120" y="30" fill="var(--brand)" font-size="9" font-weight="700" text-anchor="middle">LABORATORIO SENA</text><rect x="92" y="64" width="58" height="24" rx="5" fill="var(--brand)"/><text x="121" y="80" fill="#fff" font-size="9" font-weight="700" text-anchor="middle">Switch</text><rect x="26" y="44" width="48" height="20" rx="4" fill="var(--panel)" stroke="var(--brand)"/><text x="50" y="57" fill="var(--ink)" font-size="8" text-anchor="middle">Cámara</text><rect x="26" y="98" width="48" height="20" rx="4" fill="var(--panel)" stroke="var(--brand)"/><text x="50" y="111" fill="var(--ink)" font-size="8" text-anchor="middle">Cliente</text><rect x="168" y="66" width="48" height="22" rx="4" fill="var(--night)"/><text x="192" y="80" fill="#fff" font-size="8" text-anchor="middle">Servidor IA</text><line x1="74" y1="54" x2="92" y2="70" stroke="var(--brand)" stroke-width="2"/><line x1="74" y1="108" x2="92" y2="82" stroke="var(--brand)" stroke-width="2"/><line x1="150" y1="76" x2="168" y2="77" stroke="var(--brand)" stroke-width="2"/></svg>`,
    MAN: `<svg viewBox="0 0 240 150"><ellipse cx="120" cy="80" rx="80" ry="44" fill="none" stroke="var(--brand)" stroke-width="4"/><text x="120" y="84" fill="var(--brand)" font-size="9" font-weight="700" text-anchor="middle">ANILLO DE FIBRA</text><rect x="90" y="22" width="60" height="22" rx="5" fill="var(--brand)"/><text x="120" y="37" fill="#fff" font-size="8" text-anchor="middle">Sede norte</text><rect x="16" y="70" width="58" height="22" rx="5" fill="var(--night)"/><text x="45" y="85" fill="#fff" font-size="8" text-anchor="middle">Planta sur</text><rect x="166" y="70" width="60" height="22" rx="5" fill="var(--night)"/><text x="196" y="85" fill="#fff" font-size="8" text-anchor="middle">Centro control</text></svg>`,
    WAN: `<svg viewBox="0 0 240 150"><path d="M85,65 Q120,25 155,65 Q185,75 165,105 Q120,120 75,105 Q55,75 85,65 Z" fill="var(--brandbg)" stroke="var(--brand)" stroke-width="2"/><text x="120" y="78" fill="var(--brand)" font-size="10" font-weight="700" text-anchor="middle">INTERNET / ISP</text><text x="120" y="92" fill="var(--muted)" font-size="8" text-anchor="middle">enrutamiento IP global</text><rect x="10" y="65" width="48" height="24" rx="5" fill="var(--brand)"/><text x="34" y="80" fill="#fff" font-size="8" text-anchor="middle">Router A</text><rect x="182" y="65" width="48" height="24" rx="5" fill="var(--night)"/><text x="206" y="80" fill="#fff" font-size="8" text-anchor="middle">Router B</text><line x1="58" y1="77" x2="74" y2="77" stroke="var(--brand)" stroke-width="2.5"/><line x1="166" y1="77" x2="182" y2="77" stroke="var(--brand)" stroke-width="2.5"/></svg>`
  };
  const SC = {
    PAN: ['Alcance personal', 'Hasta 10 m', 'Red de área personal', 'Une dispositivos cercanos a una persona: periféricos inalámbricos, sensores portátiles y sincronización de corto alcance, sin infraestructura cableada.', 'Bluetooth, Zigbee, NFC, USB', '1 a 15 ms', 'Sensores del operario y su tablet'],
    LAN: ['Red local', 'Edificio o planta', 'Red de área local', 'Red privada de alta velocidad que une computadores, cámaras IP, switches y servidores dentro de un edificio, laboratorio o planta. De 100 Mbps a 10 Gbps con latencia mínima.', 'Ethernet (IEEE 802.3), Wi-Fi (802.11), VLAN', 'menos de 1 a 5 ms', 'Cámara, switch 2960, router y servidor YOLO'],
    MAN: ['Red metropolitana', 'Ciudad, hasta 50 km', 'Red de área metropolitana', 'Interconecta varias LAN en distintos edificios o sedes de una misma ciudad, normalmente con anillos de fibra óptica de alta capacidad.', 'Metro Ethernet, MPLS, GPON', '5 a 20 ms', 'Varios centros SENA de Bogotá'],
    WAN: ['Red amplia', 'Países e Internet', 'Red de área amplia', 'Cubre grandes distancias entre ciudades, países y continentes. Usa routers de borde, enlaces de operadores (ISP), cables submarinos y satélites.', 'IPv4/IPv6, BGP, fibra, 5G, satélite', '20 a más de 150 ms', 'Ver el video de la planta desde otra ciudad']
  };
  $('#scopeBtns').innerHTML = Object.keys(SC).map(k => `<button type="button" data-k="${k}"><span>${SC[k][0]}</span><b>${k}</b><span>${SC[k][1]}</span></button>`).join('');
  function scope(k) { const d = SC[k]; $$('#scopeBtns button').forEach(b => b.classList.toggle('on', b.dataset.k === k));
    $('#scopeSvg').innerHTML = SVG[k]; $('#scopeT').textContent = `${k}: ${d[2]}`; $('#scopeB').textContent = d[1]; $('#scopeD').textContent = d[3];
    $('#scopeN').innerHTML = [['Tecnologías', d[4]], ['Latencia típica', d[5]], ['En el proyecto', d[6]]].map(n => `<div><span>${n[0]}</span><b style="font-size:15px">${n[1]}</b></div>`).join(''); }
  $('#scopeBtns').onclick = e => { const b = e.target.closest('button'); if (b) scope(b.dataset.k); }; scope('LAN');

  const DV = {
    sw: ['Capa 2 OSI', 'Switch', 'Conecta equipos de la misma LAN usando MAC y tramas.', 'Capa 2 · enlace de datos', 'Switch Cisco 2960', 'Aprende la MAC de cada equipo y arma su tabla CAM para enviar cada trama solo al puerto del destino, sin colisiones. Además divide la red en VLAN (IEEE 802.1Q) y lleva varias VLAN por la troncal.', [['Identifica por', 'MAC (48 bits)'], ['PDU', 'Trama Ethernet'], ['En el proyecto', 'Une servidor, cliente y router']]],
    rt: ['Capa 3 OSI', 'Router', 'Une redes distintas, enruta por IP, hace NAT y QoS.', 'Capa 3 · red', 'Router (router-on-a-stick)', 'Interconecta redes lógicamente distintas: entre VLAN con subinterfaces, o la LAN con Internet. Lee la IP destino, elige la ruta, baja el TTL, traduce direcciones con NAT y administra las colas de QoS por DSCP.', [['Identifica por', 'IP (IPv4 / IPv6)'], ['PDU', 'Paquete IP'], ['En el proyecto', 'Inter-VLAN, NAT y QoS AF41']]],
    sv: ['Capa 7 · host', 'Servidor', 'Procesa servicios y ejecuta el modelo YOLOv8n.', 'Capa 7 · aplicación', 'Servidor de inferencia', 'Computador que presta servicios a otros. Aquí recibe la cámara, ejecuta YOLOv8n para detectar personas y autos, codifica el video en H.264 y lo publica por RTSP con MediaMTX.', [['Identifica por', 'IP fija + puerto (8554 RTSP)'], ['PDU', 'Datos de aplicación'], ['En el proyecto', '192.168.10.10 · VLAN 10']]],
    cl: ['Capa 7 · terminal', 'Cliente', 'El equipo del usuario que pide y muestra el video.', 'Capa 7 · aplicación', 'Cliente de monitoreo (VLC)', 'Dispositivo final que pide un servicio al servidor. Recibe los paquetes RTP, los guarda un momento en el búfer contra jitter, decodifica el video y muestra las detecciones en pantalla.', [['Identifica por', 'IP + aplicación'], ['PDU', 'Datos de usuario (video)'], ['En el proyecto', '192.168.20.10 · VLAN 20']]]
  };
  $('#devBtns').innerHTML = Object.keys(DV).map(k => `<button type="button" data-k="${k}"><small>${DV[k][0]}</small><b>${DV[k][1]}</b><span>${DV[k][2]}</span></button>`).join('');
  function dev(k) { const d = DV[k]; $$('#devBtns button').forEach(b => b.classList.toggle('on', b.dataset.k === k)); $('#devL').textContent = d[3]; $('#devT').textContent = d[4]; $('#devD').textContent = d[5]; $('#devS').innerHTML = d[6].map(r => `<div><span>${r[0]}</span><b>${r[1]}</b></div>`).join(''); }
  $('#devBtns').onclick = e => { const b = e.target.closest('button'); if (b) dev(b.dataset.k); }; dev('sw');

  /* LAN contra WAN */
  let pkt = null, vis = false, lt = performance.now();
  const MSG = { LAN: '<b>Tráfico LAN (capa 2):</b> el servidor envía una trama Ethernet con la MAC del cliente. El switch busca esa MAC en su tabla y la entrega por el puerto correcto, sin pasar por el router.', WAN: '<b>Tráfico WAN (capa 3):</b> el destino está en otra red. La trama va al router, que lee la IP, aplica NAT (192.168.x.x → 200.1.1.2) y QoS, y lo enruta por el ISP hasta el cliente remoto.' };
  $('#lanBtn').onclick = () => { pkt = { m: 'LAN', p: 0 }; $('#lwMsg').innerHTML = MSG.LAN; };
  $('#wanBtn').onclick = () => { pkt = { m: 'WAN', p: 0 }; $('#lwMsg').innerHTML = MSG.WAN; };
  function lw(now) { const dt = Math.min(.05, (now - lt) / 1000); lt = now;
    if (vis) { const { x, W, H } = prep($('#lwCv')); x.clearRect(0, 0, W, H); const sm = W < 600, bw = sm ? 74 : 110, ink = css('--ink'), mu = css('--muted'), br = css('--brand'), pn = css('--panel');
      const N = { s: [W * .12, H * .5, 'Servidor IA', '192.168.10.10'], w: [W * .36, H * .5, 'Switch L2', 'tabla MAC'], r: [W * .62, H * .26, 'Router L3', 'IP · NAT · QoS'], c: [W * .62, H * .76, 'Cliente LAN', 'misma red'], i: [W * .88, H * .26, 'Cliente WAN', 'otra ciudad'] };
      x.strokeStyle = css('--line'); x.lineWidth = 3; x.beginPath(); [['s', 'w'], ['w', 'c'], ['w', 'r'], ['r', 'i']].forEach(([a, b]) => { x.moveTo(N[a][0], N[a][1]); x.lineTo(N[b][0], N[b][1]); }); x.stroke();
      Object.values(N).forEach(n => { x.fillStyle = pn; x.strokeStyle = br; x.lineWidth = 2; rr(x, n[0] - bw / 2, n[1] - 20, bw, 40, 9); x.fill(); x.stroke(); x.fillStyle = ink; x.textAlign = 'center'; x.font = `600 ${sm ? 10 : 13}px "IBM Plex Sans",sans-serif`; x.fillText(n[2], n[0], n[1] - 2); x.fillStyle = mu; x.font = `${sm ? 9 : 11}px "IBM Plex Mono",monospace`; x.fillText(n[3], n[0], n[1] + 12); });
      if (pkt) { pkt.p += dt * (RM ? 2 : .55); const path = pkt.m === 'LAN' ? ['s', 'w', 'c'] : ['s', 'w', 'r', 'i'], segs = path.length - 1, k = Math.min(segs - 1e-6, pkt.p * segs), i = Math.floor(k), f = k - i, a = N[path[i]], b = N[path[i + 1]];
        const px = a[0] + (b[0] - a[0]) * f, py = a[1] + (b[1] - a[1]) * f; x.fillStyle = css('--vid'); x.beginPath(); x.arc(px, py, 9, 0, 7); x.fill(); x.fillStyle = '#fff'; x.beginPath(); x.arc(px, py, 3.5, 0, 7); x.fill();
        x.fillStyle = ink; x.font = '600 12px "IBM Plex Mono",monospace'; x.fillText(pkt.m === 'LAN' ? 'trama · MAC destino' : (i >= 2 ? 'paquete IP (NAT)' : 'trama → router'), px, py - 16); if (pkt.p >= 1) pkt = null; }
      x.textAlign = 'left'; }
    requestAnimationFrame(lw); }
  requestAnimationFrame(lw);
  onRoute((p, s) => vis = p === 'simulacion' && s === 'guia');

  /* tráfico y enlace */
  function traf() { const bw = +$('#tBw').value, bg = +$('#tBg').value, vi = +$('#tVi').value, om = bw * bg / 100, tot = om + vi;
    $('#tBwV').textContent = bw + ' Mbps'; $('#tBgV').textContent = bg + ' % · ' + nf(om, 1) + ' Mbps'; $('#tViV').textContent = nf(vi, 1) + ' Mbps';
    $('#tBarV').style.width = Math.min(100, vi / bw * 100) + '%'; $('#tBarO').style.width = Math.min(100 - Math.min(100, vi / bw * 100), om / bw * 100) + '%';
    $('#tUse').textContent = Math.round(tot / bw * 100) + ' %'; $('#tFree').textContent = nf(Math.max(0, bw - tot), 1) + ' Mbps';
    const m = $('#tMsg'); if (tot > bw) { m.className = 'badge bad'; m.textContent = 'Saturado: cola llena y pérdida'; } else if (tot > bw * .85) { m.className = 'badge warn'; m.textContent = 'Cerca del límite: sube la latencia'; } else { m.className = 'badge ok'; m.textContent = 'Sin pérdida'; } }
  ['#tBw', '#tBg', '#tVi'].forEach(i => $(i).addEventListener('input', traf)); traf();

  /* YOLO: una etapa contra dos */
  const AR = { yolo: ['Detector de una etapa · tiempo real', 'YOLO mira la imagen una sola vez', 'Divide la imagen en rejillas y, en una sola pasada de la red neuronal, cada celda predice cajas y probabilidades de clase. Por eso es lo bastante rápido para video en vivo.', [['Velocidad', '30 a más de 100 FPS en GPU'], ['Pasadas por imagen', 'Una sola']]],
    two: ['Detector de dos etapas · R-CNN', 'Primero propone, después clasifica', 'Los detectores clásicos como Faster R-CNN generan primero miles de regiones candidatas y luego clasifican cada una. Son precisos, pero mucho más lentos para videovigilancia en vivo.', [['Velocidad', 'de 5 a 15 FPS en GPU'], ['Pasadas', 'Propuestas + clasificador']]] };
  function arch(k) { const a = AR[k]; $$('[data-arch]').forEach(b => { b.classList.toggle('on', b.dataset.arch === k); b.classList.toggle('ghost', b.dataset.arch !== k); }); $('#arB').textContent = a[0]; $('#arT').textContent = a[1]; $('#arD').textContent = a[2]; $('#arN').innerHTML = a[3].map(n => `<div><span>${n[0]}</span><b style="font-size:15px">${n[1]}</b></div>`).join(''); }
  $$('[data-arch]').forEach(b => b.onclick = () => arch(b.dataset.arch)); arch('yolo');

  /* latencia */
  const LT = [['Exposición del cuadro (½ cuadro)', 17, '#60a5fa'], ['Inferencia YOLOv8n en CPU', 46, '#ff9a3d'], ['Codificación H.264', 9, '#3fd49c'], ['Red y cola del router (sin congestión)', 2, '#c084fc'], ['Búfer de VLC (network-caching)', 300, '#8ea0bd'], ['Decodificación y pantalla', 12, '#f472b6']], LM = 300, LS = LT.reduce((a, b) => a + b[1], 0);
  $('#latBars').innerHTML = LT.map(l => `<div class="hb"><span>${l[0]}</span><div class="t"><i style="background:${l[2]};width:${Math.max(1, l[1] / LM * 100)}%"></i></div><b>≈ ${l[1]} ms</b></div>`).join('') + `<div class="hb" style="font-weight:700"><span>Total aproximado</span><div></div><b>≈ ${LS} ms</b></div>`;
})();
