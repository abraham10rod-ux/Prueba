/* Vista sencilla: tres situaciones de la red, con y sin QoS */
(() => {
  const { $, $$, nf, prep, RM, onRoute } = FG;
  /* valores ilustrativos: [retardo video ms, pérdida video %, pérdida oficina %, uso enlace %, tráfico oficina 0-1] */
  const S = {
    normal: { qos: [18, 0, 0, 45, .25], no: [18, 0, 0, 45, .25], t: 'Todo normal', c: '', r: 'Enlace 20 Mbps' },
    alto: { qos: [24, 0, .5, 88, .75], no: [45, .5, .5, 88, .75], t: 'Tráfico alto', c: 'warn', r: 'Enlace ocupado 88 %' },
    cong: { qos: [38, .2, 18, 100, .95], no: [140, 12.5, 12.5, 100, .95], t: 'Congestión y pérdida', c: 'bad', r: 'Cola llena: descartes' }
  };
  let st = 'normal', vis = false, P = [], last = performance.now();
  const cur = () => S[st][$('#sQos').checked ? 'qos' : 'no'];
  function ui() {
    const v = cur(), s = S[st];
    $$('.sst').forEach(b => b.classList.toggle('on', b.dataset.s === st));
    $('#sStat').className = 'sstat ' + s.c; $('#sStat span').textContent = s.t;
    const d = $('#sDelay'); d.textContent = `Retardo: ${v[0]} ms` + (v[1] > 2 ? ' · se congela' : ''); d.className = 'chip2 ' + (v[0] > 100 ? 'bad' : v[0] > 30 ? 'warn' : 'ok');
    const r = $('#sRouter'); r.textContent = s.r; r.className = 'chip2 ' + s.c;
    $('#sDrop').setAttribute('opacity', st === 'cong' ? 1 : 0); $('#sLag').hidden = v[1] < 2;
    $('#sKpi').innerHTML = [['Retardo del video', v[0] + ' ms'], ['Pérdida de video', nf(v[1], 1) + ' %'], ['Pérdida de oficina', nf(v[2], 1) + ' %'], ['Uso del enlace', v[3] + ' %']].map(k => `<div><span>${k[0]}</span><b>${k[1]}</b></div>`).join('');
  }
  $$('.sst').forEach(b => b.onclick = () => { st = b.dataset.s; ui(); });
  $('#sQos').onchange = ui;
  function draw(now) {
    const dt = Math.min(.05, (now - last) / 1000); last = now;
    if (vis) {
      const { x, W, H } = prep($('#sCv')), v = cur(), y = H / 2, xs = [.1, .32, .55, .76, .9].map(f => f * W), lbl = ['Cámara + servidor', 'Switch', 'Router', '', 'Cliente'];
      x.clearRect(0, 0, W, H); x.strokeStyle = '#7dd3fc'; x.lineWidth = 5; x.beginPath(); x.moveTo(xs[0], y); x.lineTo(xs[4], y); x.stroke();
      if (!RM) { if (Math.random() < .45) P.push({ x: xs[0], v: 190 + Math.random() * 60, k: 'v' }); if (Math.random() < v[4] * .9) P.push({ x: xs[1], v: 160 + Math.random() * 80, k: 'o', y: (Math.random() - .5) * 10 }); }
      for (let i = P.length - 1; i >= 0; i--) { const p = P[i];
        if (p.fall !== undefined) { p.fall += dt; x.globalAlpha = Math.max(0, 1 - p.fall); x.fillStyle = '#ff5a5a'; x.beginPath(); x.arc(p.x + p.fall * 20, y + 10 + p.fall * p.fall * 160, 4.5, 0, 7); x.fill(); x.globalAlpha = 1; if (p.fall > 1) P.splice(i, 1); continue; }
        const prev = p.x; p.x += p.v * dt;
        if (prev < xs[2] && p.x >= xs[2]) { const loss = p.k === 'v' ? v[1] : v[2]; if (Math.random() * 100 < loss) { p.fall = 0; continue; } }
        if (p.x > xs[4]) { P.splice(i, 1); continue; }
        x.fillStyle = p.k === 'v' ? '#ff9a3d' : '#8ea0bd'; x.beginPath(); x.arc(p.x, y + (p.k === 'v' ? -6 : 6 + (p.y || 0) * .2), p.k === 'v' ? 5 : 4, 0, 7); x.fill(); }
      const bw = Math.min(124, W * .16);
      [0, 1, 2, 4].forEach(i => { x.fillStyle = '#ffffff'; x.strokeStyle = i === 2 && st === 'cong' ? '#e5484d' : '#0284c7'; x.lineWidth = 2; FG.rr(x, xs[i] - bw / 2, y - 22, bw, 44, 9); x.fill(); x.stroke();
        x.fillStyle = '#0c2a43'; x.textAlign = 'center'; x.font = `600 ${W < 600 ? 10 : 13}px "IBM Plex Sans",sans-serif`; x.fillText(lbl[i], xs[i], y + 5); });
      const q = st === 'normal' ? .1 : st === 'alto' ? .6 : 1; x.fillStyle = '#cfe9f8'; x.fillRect(xs[2] - bw / 2, y + 30, bw, 8); x.fillStyle = q > .9 ? '#ff5a5a' : '#ff9a3d'; x.fillRect(xs[2] - bw / 2, y + 30, bw * q, 8);
      x.fillStyle = '#4f6b84'; x.font = '12px "IBM Plex Mono",monospace'; x.fillText('cola del router', xs[2], y + 54); x.textAlign = 'left';
    }
    requestAnimationFrame(draw);
  }
  onRoute((p, s) => vis = p === 'simulacion' && s === 'simple');
  ui(); requestAnimationFrame(draw);
})();
